RIDE SHARE — GUI SNAPSHOT (8828381, 2026-08-31)
======================================================

The complete GUI exactly as it was tracked at commit 8828381ccd1dfe8c1d7ea2e87f37dfff696ddd15,
captured with `git archive` before the design renewal began.

Open it:   unzip -d /tmp/gui archive/gui-before-renewal-2026-08-31-8828381.zip
           then open /tmp/gui/snapshot/apps/web/dist-preview.html in a
           browser — the built single-file app, no server needed.

Restore it: see "restore" in manifest.json. Git history stays the
authoritative revert path; this zip is the portable record.

Contents: manifest.json (every file + sha256) and snapshot/ (repo paths).
