LANDING DEAD CODE — captured before removal (2026-09-04)

What this is. A byte-exact copy of apps/web and packages/brand at the commit that still carried the
items named in manifest.json under "removedByThisChange". The owner asked for a backup before the
dead list was cleared, and this is it: recovery does not depend on trusting git history alone, and
nothing in here needs a server, a network or a build to read.

Why those items were dead. Two sentences in the landing's copy table, in both languages, that no
module reads; the optional-body path of mkStep after every step grew a body in round 6; and Katibeh
— the second Arabic masthead the owner offered, kept in the fonts directory as an alternative and
never selected. They were reported rather than deleted until the owner chose removal with a backup
first.

How to use it.
  unzip -d . archive/landing-dead-code-before-removal-2026-09-04-8ce3b0a.zip
  open snapshot/apps/web/dist-preview.html      # the page exactly as it was, standalone
  cat manifest.json                             # every file with its sha256, plus the restore lines
  git checkout <commit> -- <path>               # or restore one file into the working tree

Git history remains the authoritative revert path; this archive is the portable record.
